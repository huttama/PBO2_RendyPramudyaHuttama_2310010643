/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configdb;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class tbl_questions {
    private String namadb = "pbo2_2310010643";
    private String url = "jdbc:mysql://localhost:3306/" + namadb;
    private String username = "root";
    private String password = "";
    private Connection koneksi;
    public Integer VAR_question_id = null;
    public Integer VAR_task_id = null;
    public String VAR_nilai = null;
    public String VAR_tanggal_selesai= null;
    public boolean validasi = false;

    public tbl_questions(){
        try {
            Driver mysqlDriver = new com.mysql.cj.jdbc.Driver();
            DriverManager.registerDriver(mysqlDriver);
            koneksi = DriverManager.getConnection(url, username, password);
            System.out.println("Berhasil dikoneksikan ke database");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
        }
    }

    public void SimpanAnggota(Integer question_id,Integer task_id, String nilai,
                              String tanggal_selesai){
        try {
            // gunakan nama tabel yang benar
            String sql = "INSERT INTO questions (question_id, task_id, nilai, tanggal_selesai) "
                       + "VALUES('"+question_id+"', '"+task_id+"', '"+nilai+"', '"+tanggal_selesai+"')";

            // cek apakah id sudah ada
            String cekPrimary = "SELECT * FROM questions WHERE question_id = '"+question_id+"'";

            Statement check = koneksi.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);

            if (data.next()) {
                JOptionPane.showMessageDialog(null, "ID petugas sudah terdaftar!");
                this.VAR_question_id= data.getInt("question_id");
                this.VAR_task_id = data.getInt("task_id");
                this.VAR_nilai = data.getString("nilai");
                this.VAR_tanggal_selesai = data.getString("tanggal_selesai");
                this.validasi = true;
            } else {
                this.validasi = false;
                Statement perintah = koneksi.createStatement();
                perintah.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Data berhasil disimpan!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void ubahAnggota(Integer question_id,Integer task_id, String nilai,
                            String tanggal_selesai){
        try {
            // nama tabel dan kolom disesuaikan
            String sql = "UPDATE questions SET task_id=?, nilai=?, tanggal_selesai=?WHERE question_id=?";

            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setInt(1,task_id);
            perintah.setString(2, nilai);
            perintah.setString(3, tanggal_selesai);
            perintah.setInt(4, question_id);
            perintah.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void hapusAnggota01(Integer ID){
        try {
            // hapus dari tabel yang benar
            String sql = "DELETE FROM questions WHERE question_id='"+ID+"'";

            Statement perintah = koneksi.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void tampilDataAnggota (JTable komponenTable, String SQL) {
        try {
            Statement perintah = koneksi.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("question_id");
            modelTable.addColumn("task_id");
            modelTable.addColumn("nilai");
            modelTable.addColumn("tanggal_selesai");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next()) {
                Object[] row = new Object[jumKolom];
                
                for(int i = 1; i <= jumKolom; i++) {
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.koneksi);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
}
