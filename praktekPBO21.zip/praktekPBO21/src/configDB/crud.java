package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;

public class crud {
    private String namaDB = "praktekpbo2";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection koneksi;
    public String VAR_NAMA = null;
    public String VAR_STATUS = null;
    public String VAR_TELP = null;
    public boolean validasi = false;
    
    public crud() {
        try {
            Driver mysqldriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(mysqldriver);
            koneksi = DriverManager.getConnection(url,username,password);
            System.out.println("Berhasil Dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
            
        }
    }
    
    public void simpanAnggota01(String ID, String nama, String status, String telp){
        try {
            String sql = "insert into anggota(IDAnggota, Nama, status, telp) " + "values('"+ID+"', '"+nama+"', '"+status+"', '"+telp+"')";
            String cekPrimary = "select * from anggota where IDAnggota = '"+ID+"'";
            Statement check = koneksi.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "Id Anggota Sudah Terdaftar");
                this.VAR_NAMA = data.getString("Nama");
                this.VAR_STATUS = data.getString("status");
                this.VAR_TELP = data.getString("telp");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA = null;
                this.VAR_STATUS = null;
                this.VAR_STATUS = null;
                Statement perintah = koneksi.createStatement();
                perintah.execute(sql);
                JOptionPane.showMessageDialog(null,"Data Berhasil Disimpan");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanAnggota02(String ID, String nama, String status, String telp){
        try {
            String sql = "insert into anggota(IDAnggota, Nama, status, telp) value(?, ?, ?, ?)";
            String cekPrimary = "select * from anggota where IDAnggota = ?";
            PreparedStatement check = koneksi.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "Id Anggota Sudah Terdaftar");
                this.VAR_NAMA = data.getString("Nama");
                this.VAR_STATUS = data.getString("status");
                this.VAR_TELP = data.getString("telp");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA = null;
                this.VAR_STATUS = null;
                this.VAR_STATUS = null;
                PreparedStatement perintah = koneksi.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, nama);
                perintah.setString(3, status);
                perintah.setString(4, telp);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Data Berhasil Disimpan");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahAnggota01(String ID, String nama, String status, String telp){
        try {
            String sql = "update anggota set nama = '"+nama+"', status = '"+status+"'" + ", telp = '"+telp+"' where IDAnggota = '"+ID+"'";
            Statement perintah = koneksi.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data Berhasil Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahAnggota02(String ID, String nama, String status, String telp){
        try {
            String sql = "update anggota set nama =?, status =?, telp =? where IDAnggota = ?";
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, nama);
            perintah.setString(2, status);
            perintah.setString(3, telp);
            perintah.setString(4, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Berhasil Diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusAnggota01(String ID){
        try {
            String sql = "delete from anggota where IDAnggota = '"+ID+"'";    
            Statement perintah = koneksi.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusAnggota02(String ID){
        try {
            String sql = "delete from anggota where IDAnggota = ?";      
            PreparedStatement perintah = koneksi.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataAnggota (JTable komponenTable, String SQL) {
        try {
            Statement perintah = koneksi.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("IDAnggota");
            modelTable.addColumn("Nama");
            modelTable.addColumn("status");
            modelTable.addColumn("telp");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next()) {
                Object[] row = new Object[jumKolom];
                
                for(int i = 1; i <= jumKolom; i++) {
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
}
