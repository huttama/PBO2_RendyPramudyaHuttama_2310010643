package praktekpbo2;
import frame.frameAnggota;
//import configDB.crud;

public class Praktekpbo2 {
    public static void main(String[] args) {
        //crud tes = new crud();
        //tes.simpanAnggota01("0075", "Muhammad Raldi Ariyandi", "Mahasiswa", "089620361578");
        //tes.simpanAnggota02("0102", "Rizky Fadillah", "Mahasiswa", "089620361578");
        //tes.ubahAnggota01("0102", "Rizky Fadillah", "Menikah", "089620361578");
        //tes.ubahAnggota02("0102", "Arya Saputra", "Jomblo", "08962036157888");
        //tes.hapusAnggota01("0102");
        //tes.hapusAnggota02("ID01");
        new frameAnggota().setVisible(true);
    }   
}
